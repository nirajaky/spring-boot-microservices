package com.nirajaky.doscoveryserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DoscoveryServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(DoscoveryServerApplication.class, args);
	}

}
